References:
- Udacity.com: For the project, the major source consulted was the PDSND classroom content. 
- Pandas.pydata.org: The Pandas documentation
- Stackoverflow.com: A lot of help with filtering 
- Google.com: help with other problems, the ultimate source. 